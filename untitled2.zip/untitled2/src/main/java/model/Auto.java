package model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor

public abstract class Auto {

    private String tuition;
    private int year;
    private int cv;
    private String marc;
    private String color;
    private int km;

    private double price;




    public Auto(String tuition, int year, int cv, String marc, String color, int km) {
        this.tuition = tuition;
        this.year = year;
        this.cv = cv;
        this.marc = marc;
        this.color = color;
        this.km = km;
    }

    public abstract void calcPrice();

    public void showData(){
        System.out.println("tuition = " + tuition);
        System.out.println("year = " + year);
        System.out.println("cv = " + cv);
        System.out.println("marc = " + marc);
        System.out.println("color = " + color);
        System.out.println("km = " + km);
        System.out.println("price = " + price);
    }

}
