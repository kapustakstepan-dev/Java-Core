package model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor

public class Bus extends Auto {

    private int numPassengers;

    @Override
    public void calcPrice() {
        
    }

    @Override
    public void showData() {
        super.showData();

    }
}
