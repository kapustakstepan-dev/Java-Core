package com.example.tienda.controller;

import com.example.tienda.TiendaApplication;
import com.example.tienda.data.DataSet;
import com.example.tienda.model.User;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Stack;

public class AdminController implements Initializable {

    @FXML
    private Button btnADD, btnDetail, btnLogOut, btnRemove;

    @FXML
    private Text btnSaludo, txtAdmin, txtName ,txtUsers ;

    @FXML
    private ListView<User> listView;


    private User user;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initGUI();
        actions();
    }

    private void actions() {
        btnADD.setOnAction(event -> {
            FXMLLoader loader = new FXMLLoader(TiendaApplication.class.getResource("register-view.fxml"));
            try {
                Parent root = loader.load();
                RegisterController registerController = loader.getController();
                registerController.setAdminController(AdminController.this);
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


        });
        btnRemove.setOnAction(actionEvent -> {
            User userDEl = listView.getSelectionModel().getSelectedItem();



        });
    }

    private void initGUI() {

       listView.setItems(DataSet.getList());
       refreshNumbers();

    }

    public void refreshNumbers(){
        txtUsers.setText("El total de usuarios es de "+DataSet.getList().size());
        txtAdmin.setText("El total de usuarios es de "+DataSet.getAdmins());
    }



    public void setUser(String corrreo) {
        this.user = DataSet.getUser(corrreo);
        txtName.setText("Bienvenido "+user.getName());
    }
}
